package appiumLiveProject;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.Assert;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class googleKeepApp2 {
  
	WebDriverWait wait;	
    AppiumDriver<MobileElement> driver = null;
    
  @BeforeClass
  public void beforeClass() throws MalformedURLException {
	  
	  DesiredCapabilities caps = new DesiredCapabilities();
      caps.setCapability("deviceName", "Pixel 2 API 26");	
      caps.setCapability("platformName", "Android");
      caps.setCapability("appPackage", "com.google.android.keep");  	
      caps.setCapability("appActivity", ".activities.BrowseActivity");
      
      driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);	
	  
  }
  
  @Test
  public void noteWithReminder() {
	  
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  driver.findElementById("com.google.android.keep:id/new_note_button").click();
	  driver.findElementById("com.google.android.keep:id/editable_title").sendKeys("Hello");
	  driver.findElementById("com.google.android.keep:id/edit_note_text").sendKeys("Writing Simple Note");
	  driver.findElementById("com.google.android.keep:id/menu_reminder").click();
	  driver.findElementByXPath("//android.widget.LinearLayout[@content-desc=\"Time - Currently selected - 3:00 PM\"]/android.widget.Spinner").click();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  driver.findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.TextView[2]").click();
	  driver.findElementById("com.google.android.keep:id/save").click();
	  driver.findElement(MobileBy.AccessibilityId("Open navigation drawer")).click();
	  String Title = driver.findElementByXPath("//androidx.cardview.widget.CardView[@content-desc=\"Hello. Writing Simple Note. \"]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.TextView[1]").getText();
	  Assert.assertEquals("Hello", Title);
	  System.out.println("Title of the new note is: "+ Title);
	  String reminder = driver.findElementById("com.google.android.keep:id/reminder_chip_text").getText();
	  System.out.println("Note is added with Reminder time is: "+ reminder);
	  Assert.assertEquals("Today, 1:00 PM", reminder);
	  
  }

  @AfterClass
  public void afterClass() {
	  
	  //driver.quit();
  }

}
