package appiumLiveProject;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.Assert;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class googleTaskApp {
	
    WebDriverWait wait;	
    AppiumDriver<MobileElement> driver = null;
    
	
    
   @BeforeClass
	  public void beforeClass() throws MalformedURLException {
		  
		  DesiredCapabilities caps = new DesiredCapabilities();
	      caps.setCapability("deviceName", "Pixel 2 API 26");	
	      caps.setCapability("platformName", "Android");
	      caps.setCapability("appPackage", "com.google.android.apps.tasks");  	
	      caps.setCapability("appActivity", ".ui.TaskListsActivity");
	      
	      driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);	
	      
	      
   }
   
   @Test (priority=0)
      public void taskAdd1() throws InterruptedException {
	  
	  
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   driver.findElementById("com.google.android.apps.tasks:id/welcome_get_started").click();
	   MobileElement newTask = driver.findElementById("com.google.android.apps.tasks:id/tasks_fab");
	   newTask.click();
	   MobileElement addTask = driver.findElementById("com.google.android.apps.tasks:id/add_task_title");
	   MobileElement saveButton = driver.findElementById("com.google.android.apps.tasks:id/add_task_done");
	   addTask.sendKeys("Complete Activity with Google Tasks");
	   saveButton.click();
	   driver.findElementById("com.google.android.apps.tasks:id/tasks_item_completed_check").click();
	   driver.findElementById("com.google.android.apps.tasks:id/expand").click();
	   String getTaskName1 = driver.findElementById("com.google.android.apps.tasks:id/task_name").getText();
	   Assert.assertEquals("Complete Activity with Google Tasks", getTaskName1); 
	   System.out.println(getTaskName1);
	  
   }
	  
   	@Test(priority=1)
   		public void taskAdd2() throws InterruptedException {
	  
   			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   			driver.findElementById("com.google.android.apps.tasks:id/tasks_fab").click();
   			Thread.sleep(2000);
   			driver.findElementById("com.google.android.apps.tasks:id/add_task_title").sendKeys("Complete Activity with Google Keep");
   			driver.findElementById("com.google.android.apps.tasks:id/add_task_done").click();
   			driver.findElementByXPath("//android.view.View[@content-desc=\"Mark as complete\"]").click();
   			String getTaskName2 = driver.findElementById("com.google.android.apps.tasks:id/task_name").getText();
   			Assert.assertEquals("Complete Activity with Google Keep", getTaskName2);
   			System.out.println(getTaskName2);
	  
   	}
  
   	@Test(priority=2)
   		public void taskAdd3() throws InterruptedException {
	  
   			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   			driver.findElementById("com.google.android.apps.tasks:id/tasks_fab").click();
   			Thread.sleep(2000);
   			driver.findElementById("com.google.android.apps.tasks:id/add_task_title").sendKeys("Complete the second Activity Google Keep");
   			driver.findElementById("com.google.android.apps.tasks:id/add_task_done").click();
   			driver.findElementByXPath("//android.view.View[@content-desc=\"Mark as complete\"]").click();
   			String getTaskName3 = driver.findElementById("com.google.android.apps.tasks:id/task_name").getText();
   			Assert.assertEquals("Complete the second Activity Google Keep", getTaskName3);
   			System.out.println(getTaskName3);
   	}
  

   	@AfterClass
   		public void afterClass() {
   			driver.quit();
   	}

}
