package appiumLiveProject;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.Assert;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class browserTodoListActivity {
	
	WebDriverWait wait;	
    AppiumDriver<MobileElement> driver = null;
    
    
  
  @BeforeClass
  public void beforeClass() throws MalformedURLException {
	  
	  DesiredCapabilities caps = new DesiredCapabilities();
      caps.setCapability("deviceName", "Pixel 2 API 26");	
      caps.setCapability("platformName", "Android");
      caps.setCapability("appPackage", "com.android.chrome");  	
      caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");
      caps.setCapability("noReset", true);
      
      URL appserver = new URL("http://127.0.0.1:4723/wd/hub");
      driver = new AndroidDriver<MobileElement>(appserver, caps);
      
  }

  @Test
  public void ToDoList() {
	  
	
		 
	  try {
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  driver.get("https://www.training-support.net/selenium");
	  }catch (Exception e) {
	  
	 MobileElement todoList = driver.findElement(MobileBy.AndroidUIAutomator("UiScrollable(UiSelector()).scrollForward(50).scrollIntoView(descriptionContains(\"To-Do List\"))"));
	 todoList.click();
	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 driver.findElementById("taskInput").sendKeys("Add tasks to list");
	 driver.findElementByXPath("//android.widget.Button[@content-desc=\"Add Task\"]").click();
	 driver.findElementById("taskInput").sendKeys("Get number of tasks");
	 driver.findElementByXPath("//android.widget.Button[@content-desc=\"Add Task\"]").click();
	 driver.findElementById("taskInput").sendKeys("Clear the list");
	 driver.findElementByXPath("//android.view.View[@content-desc=\"Add tasks to list\"]").click();
	 driver.findElementByXPath("//android.view.View[@content-desc=\"Get number of tasks\"]").click();
	 driver.findElementByXPath("//android.view.View[@content-desc=\"Clear the list\"]").click();
	 driver.findElementByXPath("//android.view.View[@content-desc=\" Clear List\"]").click();
	 
	  } 
  }
  
  @AfterClass
  public void afterClass() {
	  //driver.quit();
  }

}
